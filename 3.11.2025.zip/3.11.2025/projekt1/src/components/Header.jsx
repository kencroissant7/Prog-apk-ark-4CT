function Header() {
    return(
        <>
            <div style={{width:"100%",height:"15%",border:"1px black solid",textAlign:"center",backgroundColor:"darkblue"}}>
                <h1>Tatry to moja pasja</h1>
            </div>
        </>
    )
}
export default Header